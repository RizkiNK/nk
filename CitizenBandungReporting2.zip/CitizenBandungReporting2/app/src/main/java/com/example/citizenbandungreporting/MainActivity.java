package com.example.citizenbandungreporting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;


public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;

    private final BeritaFragment beritaFragment = new BeritaFragment();
    private final HomeFragment homeFragment = new HomeFragment();
    private final KeluhanFragment keluhanFragment = new KeluhanFragment();
    private final TempatFragment tempatFragment = new TempatFragment();

    private CarouselView carouselView;

    private final int[] Images = {R.drawable.banner, R.drawable.banner2, R.drawable.banner3, R.drawable.banner4, R.drawable.banner5};
    //pembuatan array untuk menyimpan gambar
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        carouselView = findViewById(R.id.CarouselView);
        //pembuatan caraousel view
        carouselView.setPageCount(Images.length);
        //pengitungan sesuai gambar yang di butuhkan
        carouselView.setImageListener(imageListener);
        //pembuatan toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //pembuatan bottom navigation
        initView();

        loadFragment(homeFragment);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.menu_home:
                                loadFragment(homeFragment);
                                Toast.makeText(getApplicationContext(), "Ini Home", Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.menu_tempat:
                                loadFragment(tempatFragment);
                                Toast.makeText(getApplicationContext(), "Ini Tempat", Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.menu_berita:
                                loadFragment(beritaFragment);
                                Toast.makeText(getApplicationContext(), "Ini Berita", Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.menu_keluhan:
                                loadFragment(keluhanFragment);
                                Toast.makeText(getApplicationContext(), "Ini Keluhan", Toast.LENGTH_LONG).show();
                                return true;
                        }

                        return false;
                    }
                }
        );
        // pembuatan fragment


    }

    //image listener
    ImageListener imageListener = new ImageListener() {
        @Override
        public void setImageForPosition(int position, ImageView imageView) {
            imageView.setImageResource(Images[position]);

//pemanggilan image listener untuk menampilkan gambar dari array
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    private void initView(){
        bottomNavigationView = findViewById(R.id.nav_bottom);
    }

    private void loadFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.layout_content, fragment);
        fragmentTransaction.commit();
    }

}
